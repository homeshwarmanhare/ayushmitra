import fs from 'node:fs/promises';
import pdfParse from 'pdf-parse';
import Tesseract from 'tesseract.js';
import AppError from './AppError.js';

const cleanMetric = (value) => value ? value.replace(/\s+/g, ' ').trim() : null;

export function extractCbcMetrics(rawText) {
  const text = rawText.replace(/\r/g, ' ');
  const match = (pattern) => cleanMetric(text.match(pattern)?.[1]);

  return {
    hb: match(/(?:haemoglobin|hemoglobin|\bHb\b)\s*(?:\([^)]*\))?\s*[:=-]?\s*([0-9]+(?:\.[0-9]+)?\s*(?:g\/?dL)?)/i),
    wbc: match(/(?:total\s+)?(?:WBC|white\s+blood\s+(?:cell|count))\s*(?:count)?\s*[:=-]?\s*([0-9,]+(?:\.[0-9]+)?\s*(?:\/?(?:µ|u)?L|x\s*10\^?9\/?L)?)/i),
    platelets: match(/(?:platelet(?:s)?|PLT)\s*(?:count)?\s*[:=-]?\s*([0-9,.]+\s*(?:lakh(?:s)?|lac(?:s)?|x\s*10\^?9\/?L|\/?(?:µ|u)?L)?)/i),
    rawText: rawText.slice(0, 50000)
  };
}

export async function extractTextFromUpload(file) {
  if (!file) throw new AppError('A document file is required', 400);

  if (file.mimetype === 'application/pdf') {
    const buffer = await fs.readFile(file.path);
    const parsed = await pdfParse(buffer);
    return parsed.text || '';
  }

  const result = await Tesseract.recognize(file.path, 'eng');
  return result.data.text || '';
}
