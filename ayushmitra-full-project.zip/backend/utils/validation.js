import { validationResult } from 'express-validator';
import AppError from './AppError.js';

export function validateRequest(req) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    throw new AppError('Validation failed', 422, errors.array());
  }
}
