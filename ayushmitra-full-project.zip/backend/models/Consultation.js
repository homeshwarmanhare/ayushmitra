import mongoose from 'mongoose';

const consultationSchema = new mongoose.Schema(
  {
    tokenNumber: { type: String, required: true, unique: true, uppercase: true, trim: true },
    patientId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    doctorId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    opdRoom: { type: String, default: 'Room 104', trim: true },
    status: { type: String, enum: ['waiting', 'in_consultation', 'completed'], default: 'waiting', index: true },
    isRedFlag: { type: Boolean, default: false, index: true }
  },
  { timestamps: { createdAt: true, updatedAt: true }, versionKey: false }
);

consultationSchema.index({ status: 1, isRedFlag: -1, createdAt: 1 });

export default mongoose.model('Consultation', consultationSchema);
