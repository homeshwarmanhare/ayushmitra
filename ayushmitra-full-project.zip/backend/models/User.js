import mongoose from 'mongoose';

const userSchema = new mongoose.Schema(
  {
    fullName: { type: String, required: true, trim: true, maxlength: 120 },
    mobile: { type: String, required: true, unique: true, trim: true, match: /^\d{10,15}$/ },
    email: { type: String, trim: true, lowercase: true, sparse: true, match: /^\S+@\S+\.\S+$/ },
    passwordHash: { type: String, select: false },
    role: { type: String, enum: ['patient', 'doctor', 'staff'], default: 'patient' },
    abhaId: { type: String, unique: true, sparse: true, trim: true, match: /^\d{14}$/ },
    age: { type: Number, min: 0, max: 130 },
    gender: { type: String, enum: ['male', 'female', 'other', 'prefer_not_to_say'] }
  },
  { timestamps: { createdAt: true, updatedAt: true }, versionKey: false }
);

userSchema.set('toJSON', {
  transform: (_doc, ret) => {
    delete ret.passwordHash;
    return ret;
  }
});

export default mongoose.model('User', userSchema);
