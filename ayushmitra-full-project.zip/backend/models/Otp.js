import mongoose from 'mongoose';

const otpSchema = new mongoose.Schema(
  {
    mobileOrAbha: { type: String, required: true, index: true, trim: true },
    // Stores a bcrypt hash of the six-digit OTP; never return this field from the API.
    otpCode: { type: String, required: true, select: false },
    expiresAt: { type: Date, required: true, index: { expires: 0 } },
    isVerified: { type: Boolean, default: false }
  },
  { timestamps: true, versionKey: false }
);

otpSchema.index({ mobileOrAbha: 1, createdAt: -1 });

export default mongoose.model('Otp', otpSchema);
