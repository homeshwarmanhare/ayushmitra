import mongoose from 'mongoose';

const documentSchema = new mongoose.Schema(
  {
    consultationId: { type: mongoose.Schema.Types.ObjectId, ref: 'Consultation', required: true, index: true },
    fileName: { type: String, required: true },
    fileUrl: { type: String, required: true },
    fileType: { type: String, required: true },
    uploadDate: { type: Date, default: Date.now },
    ocrExtractedJson: {
      hb: { type: String, default: null },
      wbc: { type: String, default: null },
      platelets: { type: String, default: null },
      rawText: { type: String, default: '' }
    }
  },
  { timestamps: true, versionKey: false }
);

export default mongoose.model('Document', documentSchema);
