import mongoose from 'mongoose';

const clinicalHistorySchema = new mongoose.Schema(
  {
    consultationId: { type: mongoose.Schema.Types.ObjectId, ref: 'Consultation', required: true, unique: true },
    chiefComplaint: { type: String, trim: true, maxlength: 2000 },
    voiceTranscript: { type: String, maxlength: 20000 },
    aiVoiceSummary: { type: String, maxlength: 5000 },
    socrates: {
      duration: { type: String, maxlength: 500 },
      severity: { type: String, maxlength: 100 },
      associated: { type: String, maxlength: 2000 },
      denials: { type: String, maxlength: 2000 }
    },
    ayush: {
      prakriti: { type: String, maxlength: 500 },
      agni: { type: String, maxlength: 500 },
      nidra: { type: String, maxlength: 500 },
      nadi: { type: String, maxlength: 500 }
    },
    consent: {
      dataProcessing: { type: Boolean, default: false },
      voiceRecording: { type: Boolean, default: false },
      doctorSharing: { type: Boolean, default: false }
    },
    doctorNotes: { type: String, maxlength: 10000 },
    vitals: { type: String, maxlength: 2000 },
    referral: { type: String, maxlength: 2000 },
    plan: { type: String, maxlength: 5000 }
  },
  { timestamps: true, versionKey: false }
);

export default mongoose.model('ClinicalHistory', clinicalHistorySchema);
