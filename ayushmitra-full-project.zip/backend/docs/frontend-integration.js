/*
  Paste this block near the bottom of sih2.0.html, after its existing JavaScript.
  It intentionally overrides only the mock functions requested in the brief.
*/
const API_BASE = 'http://localhost:5000/api';

function apiToken() { return localStorage.getItem('ayushmitra_api_token'); }
function authHeaders(extra = {}) {
  return apiToken() ? { ...extra, Authorization: `Bearer ${apiToken()}` } : extra;
}
async function apiFetch(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, options);
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.message || `Request failed (${response.status})`);
  return payload;
}
function escapeHtml(value = '') {
  return String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[char]);
}
function toPrototypeUser(user) {
  return { id: user._id, name: user.fullName, role: user.role, mobile: user.mobile, abha: user.abhaId || 'Not provided', age: user.age || '', gender: user.gender || '' };
}

// Replace sendDemoOtp() with this function. In development, read the code from the backend terminal.
async function sendDemoOtp() {
  const identifier = document.getElementById('login-otp-identifier')?.value.trim();
  if (!identifier) return showAuthAlert('Please enter your mobile number or ABHA ID first.');
  try {
    await apiFetch('/auth/send-otp', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mobileOrAbha: identifier.replace(/\D/g, '') })
    });
    showAuthAlert('OTP sent. It is valid for 10 minutes.', 'success');
  } catch (error) { showAuthAlert(error.message); }
}

// Replace handleOtpLoginSubmit(event) with this function.
async function handleOtpLoginSubmit(event) {
  event.preventDefault();
  const mobileOrAbha = document.getElementById('login-otp-identifier').value.trim().replace(/\D/g, '');
  const otpCode = document.getElementById('input-otp-code').value.trim();
  try {
    const { token, user } = await apiFetch('/auth/verify-otp', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mobileOrAbha, otpCode })
    });
    localStorage.setItem('ayushmitra_api_token', token);
    loginUser(toPrototypeUser(user));
  } catch (error) { showAuthAlert(error.message); }
}

// Replace startNewPatientWithoutAbha() with this function.
// A patient must first be authenticated using OTP; ABHA remains optional.
async function startNewPatientWithoutAbha() {
  const mobileInput = document.getElementById('new-patient-mobile');
  const mobile = mobileInput?.value.trim();
  if (!mobile) { mobileInput?.focus(); return showToast('Please enter a mobile number.', 'error'); }
  if (!apiToken()) return showToast('Verify the patient mobile OTP before issuing a token.', 'error');
  try {
    const { consultation } = await apiFetch('/intake/session', {
      method: 'POST', headers: authHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ opdRoom: 'Room 104' })
    });
    patientData.phone = mobile;
    patientData.name = currentUser?.name || `Patient ${mobile.slice(-4)}`;
    patientData.abha = 'ABHA creation pending';
    patientData.abhaStatus = 'Not provided';
    patientData.token = consultation.tokenNumber;
    patientData.consultationId = consultation._id;
    continueWithConsent();
  } catch (error) { showToast(error.message, 'error'); }
}

// Add this to the script, then change both case-12 buttons from goToStep(13) to selectAndUploadDocument().
async function selectAndUploadDocument() {
  if (!patientData.consultationId) return showToast('Create an intake token before uploading a document.', 'error');
  const picker = document.createElement('input');
  picker.type = 'file'; picker.accept = '.pdf,image/jpeg,image/png,image/webp';
  picker.onchange = async () => {
    const file = picker.files?.[0];
    if (!file) return;
    if (file.size > 10 * 1024 * 1024) return showToast('File must be 10 MB or smaller.', 'error');
    const formData = new FormData();
    formData.append('consultationId', patientData.consultationId);
    formData.append('file', file);
    try {
      const { document: saved, extracted } = await apiFetch('/documents/upload', { method: 'POST', headers: authHeaders(), body: formData });
      patientData.documents = [...(patientData.documents || []), { name: saved.fileName, date: new Date(saved.uploadDate).toLocaleDateString(), snippet: `Hb: ${extracted.hb || 'not found'} | WBC: ${extracted.wbc || 'not found'} | Platelets: ${extracted.platelets || 'not found'}` }];
      patientData.lastOcr = extracted;
      goToStep(13); // opens the existing OCR-review screen after the real upload completes
      showToast('Document uploaded and CBC values extracted. Please verify them.', 'success');
    } catch (error) { showToast(error.message, 'error'); }
  };
  picker.click();
}

// Replace refreshDoctorQueue() with this function.
async function refreshDoctorQueue() {
  try {
    const { consultations } = await apiFetch('/doctor/queue?status=waiting', { headers: authHeaders() });
    const queue = document.getElementById('doctor-queue-list');
    const waiting = consultations.length;
    document.getElementById('doctor-stat-waiting').innerText = String(waiting);
    document.getElementById('doctor-queue-waiting-badge').innerText = `${waiting} Waiting`;
    queue.innerHTML = consultations.map((item) => {
      const patient = item.patientId || {};
      const priority = item.isRedFlag ? '<span class="text-[10px] bg-red-600 text-white px-2 py-0.5 rounded font-bold">PRIORITY</span>' : '';
      return `<button type="button" onclick="loadDoctorPatient('${escapeHtml(item.tokenNumber)}')" id="queue-item-${escapeHtml(item.tokenNumber)}" class="w-full text-left p-3 rounded-lg border border-slate-200 hover:bg-blue-50">\
        <div class="flex justify-between gap-2"><span class="font-black text-govNavy">${escapeHtml(item.tokenNumber)}</span>${priority}</div>\
        <div class="text-xs font-bold text-slate-800 mt-1">${escapeHtml(patient.fullName || 'Unknown patient')}</div>\
        <div class="text-[11px] text-slate-500">${escapeHtml(item.opdRoom)} · ${escapeHtml(patient.mobile || '')}</div></button>`;
    }).join('') || '<p class="text-xs text-slate-500 p-3">No waiting consultations.</p>';
    showToast('OPD queue refreshed.', 'success');
  } catch (error) { showToast(error.message, 'error'); }
}

// Optional but recommended: replace loadDoctorPatient() to load a real case before the existing renderer runs.
async function loadDoctorPatient(tokenId) {
  try {
    const { consultation, history, documents } = await apiFetch(`/doctor/patient/${encodeURIComponent(tokenId)}`, { headers: authHeaders() });
    const patient = consultation.patientId || {};
    patientsRegistry[tokenId] = {
      token: consultation.tokenNumber, name: patient.fullName, age: patient.age || '—', gender: patient.gender || 'Not recorded',
      abha: patient.abhaId || 'Not provided', abhaStatus: patient.abhaId ? 'Verified' : 'Not provided', isRedFlag: consultation.isRedFlag,
      chiefComplaint: history?.chiefComplaint || 'Not recorded', voiceTranscript: history?.voiceTranscript || '', aiVoiceSummary: history?.aiVoiceSummary || '',
      socrates: history?.socrates || {}, ayush: history?.ayush || {}, vitals: history?.vitals || '', doctorNotes: history?.doctorNotes || '', referral: history?.referral || '', plan: history?.plan || '',
      documents: documents.map((doc) => ({ name: doc.fileName, date: new Date(doc.uploadDate).toLocaleDateString(), snippet: `Hb: ${doc.ocrExtractedJson?.hb || '—'} | WBC: ${doc.ocrExtractedJson?.wbc || '—'}` }))
    };
    renderDoctorView(tokenId);
  } catch (error) { showToast(error.message, 'error'); }
}
