import { Router } from 'express';
import { uploadDocument, uploadValidation } from '../controllers/documentController.js';
import { requireAuth } from '../middleware/auth.js';
import upload from '../middleware/upload.js';

const router = Router();
router.post('/upload', requireAuth, upload.single('file'), uploadValidation, uploadDocument);
export default router;
