import { Router } from 'express';
import { createSession, getSummary, historyValidation, sessionValidation, summaryValidation, upsertHistory } from '../controllers/intakeController.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth);
router.post('/session', sessionValidation, createSession);
router.put('/:consultationId/history', historyValidation, upsertHistory);
router.get('/:consultationId/summary', summaryValidation, getSummary);
export default router;
