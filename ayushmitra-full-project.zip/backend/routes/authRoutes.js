import { Router } from 'express';
import { login, loginValidation, me, register, registerValidation, sendOtp, sendOtpValidation, verifyOtp, verifyOtpValidation } from '../controllers/authController.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
router.post('/send-otp', sendOtpValidation, sendOtp);
router.post('/verify-otp', verifyOtpValidation, verifyOtp);
router.post('/register', registerValidation, register);
router.post('/login', loginValidation, login);
router.get('/me', requireAuth, me);
export default router;
