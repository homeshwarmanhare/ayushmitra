import { Router } from 'express';
import { completePatientCase, getPatientCase, getQueue, queueValidation, tokenValidation, updateCaseValidation, updatePatientCase } from '../controllers/doctorController.js';
import { allowRoles, requireAuth } from '../middleware/auth.js';

const router = Router();
router.use(requireAuth, allowRoles('doctor', 'staff'));
router.get('/queue', queueValidation, getQueue);
router.get('/patient/:tokenId', tokenValidation, getPatientCase);
router.put('/patient/:tokenId/vitals', updateCaseValidation, updatePatientCase);
router.put('/patient/:tokenId/complete', tokenValidation, completePatientCase);
export default router;
