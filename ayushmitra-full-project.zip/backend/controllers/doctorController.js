import { body, param, query } from 'express-validator';
import Consultation from '../models/Consultation.js';
import ClinicalHistory from '../models/ClinicalHistory.js';
import Document from '../models/Document.js';
import User from '../models/User.js';
import AppError from '../utils/AppError.js';
import asyncHandler from '../utils/asyncHandler.js';
import { validateRequest } from '../utils/validation.js';

export const queueValidation = [
  query('status').optional().isIn(['waiting', 'in_consultation', 'completed']),
  query('redFlag').optional().isBoolean().toBoolean(),
  query('search').optional().trim().isLength({ max: 120 })
];
export const tokenValidation = [param('tokenId').trim().matches(/^[AE]-\d{3,}$/i).withMessage('Invalid token ID')];
export const updateCaseValidation = [
  ...tokenValidation,
  body('vitals').optional().isString().isLength({ max: 2000 }),
  body('doctorNotes').optional().isString().isLength({ max: 10000 }),
  body('referral').optional().isString().isLength({ max: 2000 }),
  body('plan').optional().isString().isLength({ max: 5000 })
];

async function caseByToken(tokenId) {
  const consultation = await Consultation.findOne({ tokenNumber: tokenId.toUpperCase() })
    .populate('patientId', 'fullName mobile email abhaId age gender')
    .populate('doctorId', 'fullName role');
  if (!consultation) throw new AppError('Token not found', 404);
  return consultation;
}

export const getQueue = asyncHandler(async (req, res) => {
  validateRequest(req);
  const filter = {};
  if (req.query.status) filter.status = req.query.status;
  if (req.query.redFlag !== undefined) filter.isRedFlag = req.query.redFlag;
  if (req.query.search) {
    const term = new RegExp(req.query.search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    const matchingPatients = await User.find({ $or: [{ fullName: term }, { mobile: term }, { abhaId: term }] }).select('_id');
    filter.$or = [{ tokenNumber: term }, { patientId: { $in: matchingPatients.map((patient) => patient._id) } }];
  }
  const consultations = await Consultation.find(filter)
    .populate('patientId', 'fullName mobile abhaId age gender')
    .populate('doctorId', 'fullName')
    .sort({ isRedFlag: -1, createdAt: 1 })
    .lean();
  res.json({ success: true, count: consultations.length, consultations });
});

export const getPatientCase = asyncHandler(async (req, res) => {
  validateRequest(req);
  const consultation = await caseByToken(req.params.tokenId);
  const [history, documents] = await Promise.all([
    ClinicalHistory.findOne({ consultationId: consultation._id }),
    Document.find({ consultationId: consultation._id }).sort({ uploadDate: -1 }).select('-ocrExtractedJson.rawText')
  ]);
  res.json({ success: true, consultation, history, documents });
});

export const updatePatientCase = asyncHandler(async (req, res) => {
  validateRequest(req);
  const consultation = await caseByToken(req.params.tokenId);
  const allowed = ['vitals', 'doctorNotes', 'referral', 'plan'];
  const update = Object.fromEntries(Object.entries(req.body).filter(([key, value]) => allowed.includes(key) && value !== undefined));
  if (Object.keys(update).length === 0) throw new AppError('Supply at least one clinical field to update', 422);
  const history = await ClinicalHistory.findOneAndUpdate(
    { consultationId: consultation._id },
    { $set: update },
    { new: true, upsert: true, runValidators: true }
  );
  if (!consultation.doctorId && req.user.role === 'doctor') {
    consultation.doctorId = req.user._id;
    if (consultation.status === 'waiting') consultation.status = 'in_consultation';
    await consultation.save();
  }
  res.json({ success: true, consultation, history });
});

export const completePatientCase = asyncHandler(async (req, res) => {
  validateRequest(req);
  const consultation = await caseByToken(req.params.tokenId);
  if (!consultation.doctorId) consultation.doctorId = req.user._id;
  consultation.status = 'completed';
  await consultation.save();
  res.json({ success: true, consultation });
});
