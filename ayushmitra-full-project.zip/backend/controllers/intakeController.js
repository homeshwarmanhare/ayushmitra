import { body, param } from 'express-validator';
import Consultation from '../models/Consultation.js';
import ClinicalHistory from '../models/ClinicalHistory.js';
import Document from '../models/Document.js';
import AppError from '../utils/AppError.js';
import asyncHandler from '../utils/asyncHandler.js';
import { validateRequest } from '../utils/validation.js';

export const sessionValidation = [
  body('isRedFlag').optional().isBoolean().toBoolean(),
  body('opdRoom').optional().trim().isLength({ min: 1, max: 100 }),
  body('chiefComplaint').optional().trim().isLength({ max: 2000 })
];
export const historyValidation = [
  param('consultationId').isMongoId(),
  body('chiefComplaint').optional().trim().isLength({ max: 2000 }),
  body('voiceTranscript').optional().isString().isLength({ max: 20000 }),
  body('aiVoiceSummary').optional().isString().isLength({ max: 5000 }),
  body('socrates').optional().isObject(),
  body('ayush').optional().isObject(),
  body('consent').optional().isObject()
];
export const summaryValidation = [param('consultationId').isMongoId()];

async function assertConsultationAccess(consultationId, user) {
  const consultation = await Consultation.findById(consultationId);
  if (!consultation) throw new AppError('Consultation not found', 404);
  if (user.role === 'patient' && consultation.patientId.toString() !== user.id) throw new AppError('You do not have access to this consultation', 403);
  return consultation;
}

async function nextToken(isRedFlag) {
  const prefix = isRedFlag ? 'E' : 'A';
  const count = await Consultation.countDocuments({ tokenNumber: new RegExp(`^${prefix}-`) });
  let sequence = count + 1;
  while (await Consultation.exists({ tokenNumber: `${prefix}-${String(sequence).padStart(3, '0')}` })) sequence += 1;
  return `${prefix}-${String(sequence).padStart(3, '0')}`;
}

export const createSession = asyncHandler(async (req, res) => {
  validateRequest(req);
  const { isRedFlag = false, opdRoom, chiefComplaint } = req.body;
  let consultation;
  // Retry a unique-token collision caused by simultaneous check-ins.
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      consultation = await Consultation.create({ tokenNumber: await nextToken(isRedFlag), patientId: req.user._id, opdRoom, isRedFlag });
      break;
    } catch (error) {
      if (error.code !== 11000 || attempt === 2) throw error;
    }
  }
  const history = await ClinicalHistory.create({ consultationId: consultation._id, chiefComplaint: chiefComplaint || undefined });
  res.status(201).json({ success: true, consultation, history });
});

export const upsertHistory = asyncHandler(async (req, res) => {
  validateRequest(req);
  await assertConsultationAccess(req.params.consultationId, req.user);
  const allowed = ['chiefComplaint', 'voiceTranscript', 'aiVoiceSummary', 'socrates', 'ayush', 'consent'];
  const update = Object.fromEntries(Object.entries(req.body).filter(([key, value]) => allowed.includes(key) && value !== undefined));
  const history = await ClinicalHistory.findOneAndUpdate(
    { consultationId: req.params.consultationId },
    { $set: update },
    { new: true, upsert: true, runValidators: true }
  );
  res.json({ success: true, history });
});

export const getSummary = asyncHandler(async (req, res) => {
  validateRequest(req);
  const consultation = await assertConsultationAccess(req.params.consultationId, req.user);
  const [history, documents] = await Promise.all([
    ClinicalHistory.findOne({ consultationId: consultation._id }),
    Document.find({ consultationId: consultation._id }).sort({ uploadDate: -1 })
  ]);
  res.json({ success: true, consultation, history, documents });
});
