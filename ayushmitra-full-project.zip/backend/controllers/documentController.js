import { body } from 'express-validator';
import Consultation from '../models/Consultation.js';
import Document from '../models/Document.js';
import AppError from '../utils/AppError.js';
import asyncHandler from '../utils/asyncHandler.js';
import { extractCbcMetrics, extractTextFromUpload } from '../utils/ocr.js';
import { validateRequest } from '../utils/validation.js';

export const uploadValidation = [body('consultationId').isMongoId().withMessage('A valid consultationId is required')];

export const uploadDocument = asyncHandler(async (req, res) => {
  validateRequest(req);
  const consultation = await Consultation.findById(req.body.consultationId);
  if (!consultation) throw new AppError('Consultation not found', 404);
  if (req.user.role === 'patient' && consultation.patientId.toString() !== req.user.id) throw new AppError('You do not have access to this consultation', 403);
  if (!req.file) throw new AppError('A PDF or image file is required', 400);

  const rawText = await extractTextFromUpload(req.file);
  const ocrExtractedJson = extractCbcMetrics(rawText);
  const document = await Document.create({
    consultationId: consultation._id,
    fileName: req.file.originalname,
    fileUrl: `/uploads/${req.file.filename}`,
    fileType: req.file.mimetype,
    ocrExtractedJson
  });
  res.status(201).json({ success: true, document, extracted: ocrExtractedJson });
});
