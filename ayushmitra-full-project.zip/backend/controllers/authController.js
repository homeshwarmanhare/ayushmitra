import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { body } from 'express-validator';
import User from '../models/User.js';
import Otp from '../models/Otp.js';
import AppError from '../utils/AppError.js';
import asyncHandler from '../utils/asyncHandler.js';
import { signToken } from '../utils/token.js';
import { validateRequest } from '../utils/validation.js';

const identifierRule = body('mobileOrAbha').trim().matches(/^(\d{10,15}|\d{14})$/).withMessage('Provide a 10-15 digit mobile number or a 14 digit ABHA ID');
export const sendOtpValidation = [identifierRule];
export const verifyOtpValidation = [identifierRule, body('otpCode').matches(/^\d{6}$/).withMessage('OTP must be six digits')];
export const registerValidation = [
  body('fullName').trim().isLength({ min: 2, max: 120 }),
  body('mobile').trim().matches(/^\d{10,15}$/),
  body('email').optional({ values: 'falsy' }).isEmail().normalizeEmail(),
  body('password').isLength({ min: 8, max: 128 }).withMessage('Password must be 8-128 characters'),
  body('role').optional().isIn(['patient', 'doctor', 'staff']),
  body('age').optional().isInt({ min: 0, max: 130 }).toInt(),
  body('gender').optional().isIn(['male', 'female', 'other', 'prefer_not_to_say']),
  body('createAbha').optional().isBoolean().toBoolean()
];
export const loginValidation = [
  body('identifier').trim().isLength({ min: 3, max: 120 }),
  body('password').isLength({ min: 1, max: 128 })
];

function publicUser(user) { return user.toJSON ? user.toJSON() : user; }
function responseWithSession(res, user, status = 200) {
  return res.status(status).json({ success: true, token: signToken(user), user: publicUser(user) });
}
function generateAbhaId() { return crypto.randomInt(1_000_000_000_0000, 10_000_000_000_0000).toString(); }

export const sendOtp = asyncHandler(async (req, res) => {
  validateRequest(req);
  const { mobileOrAbha } = req.body;
  const otp = crypto.randomInt(100000, 1000000).toString();
  await Otp.deleteMany({ mobileOrAbha, isVerified: false });
  await Otp.create({ mobileOrAbha, otpCode: await bcrypt.hash(otp, 12), expiresAt: new Date(Date.now() + 10 * 60 * 1000) });

  // Replace this with an approved SMS provider in production. Never include OTPs in API responses.
  if (process.env.NODE_ENV !== 'production') console.log(`[DEV OTP] ${mobileOrAbha}: ${otp}`);
  res.status(201).json({ success: true, message: 'OTP sent. It expires in 10 minutes.' });
});

export const verifyOtp = asyncHandler(async (req, res) => {
  validateRequest(req);
  const { mobileOrAbha, otpCode, fullName } = req.body;
  const otp = await Otp.findOne({ mobileOrAbha, isVerified: false, expiresAt: { $gt: new Date() } })
    .sort({ createdAt: -1 }).select('+otpCode');
  if (!otp || !(await bcrypt.compare(otpCode, otp.otpCode))) throw new AppError('Invalid or expired OTP', 401);

  otp.isVerified = true;
  await otp.save();
  const isAbha = /^\d{14}$/.test(mobileOrAbha);
  let user = await User.findOne(isAbha ? { abhaId: mobileOrAbha } : { mobile: mobileOrAbha });
  if (!user) {
    if (isAbha) throw new AppError('No patient is registered for this ABHA ID. Register first or sign in with mobile.', 404);
    user = await User.create({ fullName: fullName?.trim() || `Patient ${mobileOrAbha.slice(-4)}`, mobile: mobileOrAbha, role: 'patient' });
  }
  responseWithSession(res, user);
});

export const register = asyncHandler(async (req, res) => {
  validateRequest(req);
  const { fullName, mobile, email, password, age, gender, createAbha } = req.body;
  const role = req.body.role || 'patient';
  if (role !== 'patient' && (!process.env.REGISTRATION_SECRET || req.get('x-registration-secret') !== process.env.REGISTRATION_SECRET)) {
    throw new AppError('Doctor and staff accounts must be provisioned with the registration secret', 403);
  }
  const existing = await User.findOne({ $or: [{ mobile }, ...(email ? [{ email }] : [])] });
  if (existing) throw new AppError('A user with that mobile number or email already exists', 409);

  let abhaId;
  if (createAbha) {
    do { abhaId = generateAbhaId(); } while (await User.exists({ abhaId }));
  }
  const user = await User.create({ fullName, mobile, email: email || undefined, passwordHash: await bcrypt.hash(password, 12), role, abhaId, age, gender });
  responseWithSession(res, user, 201);
});

export const login = asyncHandler(async (req, res) => {
  validateRequest(req);
  const { identifier, password } = req.body;
  const user = await User.findOne({ $or: [{ mobile: identifier }, { email: identifier.toLowerCase() }, { abhaId: identifier }] }).select('+passwordHash');
  if (!user?.passwordHash || !(await bcrypt.compare(password, user.passwordHash))) throw new AppError('Invalid credentials', 401);
  responseWithSession(res, user);
});

export const me = asyncHandler(async (req, res) => res.json({ success: true, user: publicUser(req.user) }));
