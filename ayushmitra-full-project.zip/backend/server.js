import 'dotenv/config';
import fs from 'node:fs';
import path from 'node:path';
import cors from 'cors';
import express from 'express';
import { connectDatabase } from './config/db.js';
import authRoutes from './routes/authRoutes.js';
import intakeRoutes from './routes/intakeRoutes.js';
import documentRoutes from './routes/documentRoutes.js';
import doctorRoutes from './routes/doctorRoutes.js';
import { errorHandler, notFound } from './middleware/errorHandler.js';

const app = express();
const uploadPath = path.resolve('uploads');
fs.mkdirSync(uploadPath, { recursive: true });

const origins = (process.env.CLIENT_ORIGIN || 'http://127.0.0.1:5500,http://localhost:5500').split(',').map((item) => item.trim());
app.use(cors({ origin: (origin, callback) => callback(null, !origin || origins.includes(origin)), credentials: false }));
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: false }));
app.use('/uploads', express.static(uploadPath, { fallthrough: false, maxAge: '1d' }));

app.get('/api/health', (_req, res) => res.json({ success: true, service: 'AyushMitra API' }));
app.use('/api/auth', authRoutes);
app.use('/api/intake', intakeRoutes);
app.use('/api/documents', documentRoutes);
app.use('/api/doctor', doctorRoutes);
app.use(notFound);
app.use(errorHandler);

const port = Number(process.env.PORT || 5000);
connectDatabase()
  .then(() => app.listen(port, () => console.log(`AyushMitra API listening on http://localhost:${port}`)))
  .catch((error) => { console.error('Failed to start API:', error.message); process.exit(1); });
