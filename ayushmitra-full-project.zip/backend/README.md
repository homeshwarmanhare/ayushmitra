# AyushMitra API

Express 4 + MongoDB/Mongoose backend for SIH26047. It uses ES modules, JWT bearer authentication, bcrypt password and OTP hashing, Multer local uploads, and PDF/image CBC extraction.

## Run locally

1. Install and start MongoDB locally, or create a MongoDB Atlas database.
2. In this `backend` folder, copy `.env.example` to `.env`, set `MONGODB_URI` and a strong `JWT_SECRET`.
3. Run `npm install`, then `npm run dev`.
4. Confirm `GET http://localhost:5000/api/health` responds with `{ "success": true }`.

Uploads are saved under `backend/uploads/` and are served at `/uploads/<generated-name>`. Put this directory behind private object storage or an authenticated download route before exposing the application publicly, since medical files should not be public.

## Authentication contract

Send `Authorization: Bearer <token>` for intake, document, and doctor endpoints. `POST /api/auth/send-otp` logs the OTP only in development; integrate an approved SMS gateway for production. OTP verification automatically creates a *patient* account for an unregistered mobile number. Only a request that supplies `x-registration-secret: <REGISTRATION_SECRET>` can create doctor or staff accounts through `/register`.

## Routes

| Area | Endpoint | Auth | Purpose |
| --- | --- | --- | --- |
| Auth | `POST /api/auth/send-otp`, `/verify-otp`, `/register`, `/login` | no | OTP and password sessions |
| Auth | `GET /api/auth/me` | any user | current JWT profile |
| Intake | `POST /api/intake/session` | any user | creates A-/E- token |
| Intake | `PUT /api/intake/:consultationId/history` | owner/clinical user | records history and consent |
| Intake | `GET /api/intake/:consultationId/summary` | owner/clinical user | intake plus documents |
| Documents | `POST /api/documents/upload` | owner/clinical user | multipart `consultationId`, `file` |
| Doctor | `GET /api/doctor/queue` | doctor/staff | accepts `status`, `redFlag`, `search` |
| Doctor | `GET /api/doctor/patient/:tokenId` | doctor/staff | full case data |
| Doctor | `PUT /api/doctor/patient/:tokenId/vitals` | doctor/staff | accepts any of `vitals`, `doctorNotes`, `referral`, `plan` |
| Doctor | `PUT /api/doctor/patient/:tokenId/complete` | doctor/staff | closes consultation |

The copy-ready browser integration is in [`docs/frontend-integration.js`](docs/frontend-integration.js). It includes exact replacements for the specified prototype functions and the one-line case-12 button change for actual document selection.
