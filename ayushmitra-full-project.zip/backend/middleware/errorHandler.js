export function notFound(req, _res, next) {
  const error = new Error(`Route not found: ${req.method} ${req.originalUrl}`);
  error.statusCode = 404;
  next(error);
}

export function errorHandler(err, _req, res, _next) {
  let status = err.statusCode || 500;
  let message = err.message || 'Internal server error';

  if (err.name === 'ValidationError') { status = 422; message = 'Database validation failed'; }
  if (err.code === 11000) { status = 409; message = `${Object.keys(err.keyValue).join(', ')} already exists`; }
  if (err.name === 'CastError') { status = 400; message = 'Invalid resource identifier'; }
  if (err.code === 'LIMIT_FILE_SIZE') { status = 413; message = 'File exceeds the 10 MB upload limit'; }

  if (status >= 500 && process.env.NODE_ENV === 'production') message = 'Internal server error';
  if (status >= 500) console.error(err);
  res.status(status).json({ success: false, message, errors: err.details || undefined });
}
